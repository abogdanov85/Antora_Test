const ModalComponent={key:"",baseUrl:"",publicPages:[],async constructor(e,t){this.key=e,this.baseUrl=window.location.origin+"/account/",this.publicPages=t,this.isPublicPage()||await this.isAuth()||this.render()},isPublicPage(){var e=window.location.pathname?.split("/")?.slice(-1)?.[0];return Boolean(this.publicPages.includes(e))},async isAuth(){var e=window.localStorage.getItem(this.key);return!!e&&401!==(await fetch(this.baseUrl+"api/keep-alive",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({[this.key]:e})})).status},render(){var e=`
        <div class="back-drop" oncontextmenu="return false;">
            <div class="title">
                Для просмотра документации, необходимо авторизоваться на сайте
            </div>
            <a href='${this.baseUrl}login/?redirectTo=/helpcenter/' class="button">Войти</a>
        </div>`;document.querySelector("body").insertAdjacentHTML("beforeend",e)}};!async function(){console.log("ModalComponent / version: 0.1.5"),await ModalComponent.constructor("refreshToken",["personal-data-processing.html"])}();